# Tray Icons

Simple version of [TopIcons Plus](https://extensions.gnome.org/extension/1031/topicons/).

Base on TopIcons Plus v22 from [GNOME Shell Extensions](https://extensions.gnome.org/).

Keep it as simple as possible.
